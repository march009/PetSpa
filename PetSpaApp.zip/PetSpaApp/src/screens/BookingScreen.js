import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';

export default function BookingScreen({ navigation }) {
  const [petName, setPetName] = useState('');
  const [petType, setPetType] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [address, setAddress] = useState('');

  const handleBooking = () => {
    if (petName && date && address) {
      navigation.navigate('MyBookings', {
        booking: {
          id: Date.now().toString(),
          pet: petName,
          petType: petType,
          date: date,
          time: time,
          address: address
        },
      });
    } else {
      alert("กรุณากรอกข้อมูลให้ครบถ้วน");
    }
  };

  return (
    <KeyboardAvoidingView 
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={{ flex: 1 }}
    >
      <ScrollView style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>📅 จองบริการอาบน้ำ</Text>
          <Text style={styles.subtitle}>กรอกข้อมูลเพื่อจองคิวให้เพื่อนตัวน้อย</Text>
        </View>

        <View style={styles.formContainer}>
          <View style={styles.inputGroup}>
            <Text style={styles.label}>ข้อมูลสัตว์เลี้ยง</Text>
            <TextInput
              style={styles.input}
              placeholder="ชื่อสัตว์เลี้ยง"
              value={petName}
              onChangeText={setPetName}
            />
            <TextInput
              style={styles.input}
              placeholder="ประเภทสัตว์เลี้ยง (สุนัข, แมว, ฯลฯ)"
              value={petType}
              onChangeText={setPetType}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>วันและเวลา</Text>
            <TextInput
              style={styles.input}
              placeholder="วันที่ (เช่น 2025-04-30)"
              value={date}
              onChangeText={setDate}
            />
            <TextInput
              style={styles.input}
              placeholder="เวลา (เช่น 10:00)"
              value={time}
              onChangeText={setTime}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>ที่อยู่</Text>
            <TextInput
              style={[styles.input, styles.addressInput]}
              placeholder="ที่อยู่สำหรับรับส่ง"
              value={address}
              onChangeText={setAddress}
              multiline={true}
              numberOfLines={3}
            />
          </View>
        </View>

        <View style={styles.buttonContainer}>
          <TouchableOpacity 
            style={styles.secondaryButton} 
            onPress={() => navigation.goBack()}
          >
            <Text style={styles.secondaryButtonText}>ยกเลิก</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.primaryButton} 
            onPress={handleBooking}
          >
            <Text style={styles.primaryButtonText}>ยืนยันการจอง</Text>
          </TouchableOpacity>
        </View>
        
        <View style={styles.footer}>
          <Text style={styles.footerText}>หากมีข้อสงสัย กรุณาติดต่อ 02-XXX-XXXX</Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff8f0',
  },
  header: {
    padding: 20,
    alignItems: 'center',
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#ff6b81',
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 14,
    color: '#666',
    marginBottom: 20,
  },
  formContainer: {
    paddingHorizontal: 20,
  },
  inputGroup: {
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#444',
    marginBottom: 8,
  },
  input: {
    backgroundColor: 'white',
    borderColor: '#e0e0e0',
    borderWidth: 1,
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
    fontSize: 16,
  },
  addressInput: {
    height: 80,
    textAlignVertical: 'top',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    marginVertical: 10,
  },
  primaryButton: {
    backgroundColor: '#ff6b81',
    padding: 15,
    borderRadius: 10,
    flex: 2,
    marginLeft: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  primaryButtonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
    textAlign: 'center',
  },
  secondaryButton: {
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#ddd',
    flex: 1,
  },
  secondaryButtonText: {
    color: '#666',
    fontWeight: '600',
    fontSize: 16,
    textAlign: 'center',
  },
  footer: {
    padding: 20,
    alignItems: 'center',
    marginTop: 10,
  },
  footerText: {
    color: '#888',
    fontSize: 14,
  }
});