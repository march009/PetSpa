import React, { useEffect, useState } from 'react';
import { View, Text, Button, FlatList, StyleSheet, TouchableOpacity } from 'react-native';

export default function MyBookingsScreen({ route }) {
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    if (route.params?.booking) {
      setBookings((prev) => [...prev, route.params.booking]);
    }
  }, [route.params]);

  const cancelBooking = (id) => {
    setBookings(bookings.filter((b) => b.id !== id));
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>📖 รายการจองของฉัน</Text>
      <FlatList
        data={bookings}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.text}>🐾 {item.pet} - {item.date}</Text>
            <TouchableOpacity style={styles.cancelButton} onPress={() => cancelBooking(item.id)}>
              <Text style={styles.cancelText}>ยกเลิก</Text>
            </TouchableOpacity>
          </View>
        )}
        ListEmptyComponent={<Text style={styles.text}>ยังไม่มีการจอง</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#fff8f0' },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20, color: '#34495e' },
  card: {
    padding: 15,
    backgroundColor: '#fff',
    borderRadius: 10,
    marginBottom: 10,
    elevation: 2,
    borderColor: '#eee',
    borderWidth: 1,
  },
  text: { fontSize: 16, color: '#34495e' },
  cancelButton: {
    backgroundColor: '#ff6b6b',
    padding: 10,
    borderRadius: 8,
    marginTop: 10,
    alignItems: 'center',
  },
  cancelText: { color: 'white', fontWeight: 'bold' },
});